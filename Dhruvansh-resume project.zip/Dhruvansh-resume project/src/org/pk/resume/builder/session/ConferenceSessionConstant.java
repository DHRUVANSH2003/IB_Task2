package org.pk.resume.builder.session;

public class ConferenceSessionConstant {
	
	public static String CONFERENCE_NAME="conference_name";
	public static String CONFERENCE_TYPE="conference_type";
	public static String PAPER_TITLE="paper_title";
	public static String AUTHOR="author";
	public static String DOPUBLICATION="dopublication";
	public static String PLACE="place";
	public static String VOLUME="volume";
	public static String PAGE_N0="page_no";
	public static String DOI_NO="doi_no";
	public static String LINK = "link";
	public static String IMPACT_FACTOR="impact_factor";
	public static String IMPACT_TYPE="impact_type";

}
