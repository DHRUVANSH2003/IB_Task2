package org.pk.resume.builder.session;

public class ReferencesSessionConstant {

	public static String NAME = "name";
	public static String DESIGNATION = "designation";
	public static String AFFILIATION = "affiliation";
	public static String EMAILID = "emailId";
	public static String CONTACTNO = "contactNo";
	
}
