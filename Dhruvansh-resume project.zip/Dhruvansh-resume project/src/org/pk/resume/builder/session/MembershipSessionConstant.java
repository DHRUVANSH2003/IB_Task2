package org.pk.resume.builder.session;

public class MembershipSessionConstant 
{
	public static String NAME = "name";
	public static String PLACE = "place";
	public static String JOINING = "joining_year";
	public static String MEMBERSHIP_TYPE = "membership_type";
	public static String MEMBERSHIP_NO = "membership_no";
}
