package org.pk.resume.builder.session;

public class BookSessionConstant {

	public static String BOOK_NAME="book_name";
	public static String BOOK_AUTHOR="book_author";
	public static String PUBLISHER="publisher";
	public static String ISBN_NO="isbn_no";
	public static String PUBLICATION_DATE="publication_date";
	
	
}
